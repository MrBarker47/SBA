# About the site
So, when you click on my site. You'll notice that it starts up slow
and that's because of the photos I added. I also had an issue, with 
using the default browser but if you use live server you won't have an issue with opening up the site. 

This shows, what I'm able to do with HTML and CSS. I made three pages, that are link together. They have their own stylesheets, the home page has my images of my favorite pics that I've taken recently. About me page has gif of my favorite basketball Kobe Bryant, and a table of my favorite cartoon shows. And my contact page, has two forms on there.
You can check out the site at https://github.com/MrBarker47

## What was used to build this site
 HTML and CSS was used to build this site.

